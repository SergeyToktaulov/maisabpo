﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using unit_test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unit_test.Tests
{
    [TestClass()]
    public class MyClassTests
    {
        [TestMethod("Проверка функции сложения двух чисел")]
        public void AddTest()
        {
            MyClass mc = new MyClass();
            Assert.AreEqual(4, mc.Add(2, 2));
            Assert.AreEqual(0, mc.Add(2, -2));
            Assert.AreNotEqual(4, (2, -2));
        }

        [TestMethod()]
        public void IncTest()
        {
            MyClass mc = new MyClass();

            Assert.AreEqual(0, mc.innerCounter);
            Assert.AreEqual(3, mc.Inc(3));
            Assert.AreEqual(3, mc.innerCounter);
            Assert.AreEqual(7, mc.Add(3, 4));
            Assert.AreEqual(10, mc.innerCounter);
        }
    }
}