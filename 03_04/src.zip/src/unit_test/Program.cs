﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unit_test
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] strs = new string[] { "1", "2", "3" };
            foreach (var s in strs)
                Console.WriteLine(s);
        }


        
    }


    public class MyClass
    {
        public int innerCounter = 0;
        public int Add(int a, int b)
        {
           // innerCounter += a+b;
            return a+b;
        }

        public int Inc(int c)
        {
            innerCounter += c;
            return innerCounter;
        }
    }
}
